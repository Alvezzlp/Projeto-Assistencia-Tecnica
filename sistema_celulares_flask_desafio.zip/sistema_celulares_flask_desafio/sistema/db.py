"""Acesso ao MySQL com parâmetros para evitar SQL Injection."""
import os
from datetime import date, datetime
import mysql.connector

CONFIG = dict(host=os.getenv("DB_HOST", "localhost"), port=int(os.getenv("DB_PORT", "3306")),
              user=os.getenv("DB_USER", "root"), password=os.getenv("DB_PASSWORD", ""),
              database=os.getenv("DB_NAME", "assistencia_db"))

class ErroNegocio(Exception):
    def __init__(self, mensagem, status=400):
        super().__init__(mensagem)
        self.mensagem, self.status = mensagem, status

def _serializar(v):
    if isinstance(v, datetime): return v.isoformat(timespec="seconds")
    if isinstance(v, date): return v.isoformat()
    return v

def query(sql, params=()):
    with mysql.connector.connect(**CONFIG) as con, con.cursor(dictionary=True) as cur:
        cur.execute(sql, params)
        return [{k: _serializar(v) for k, v in r.items()} for r in cur.fetchall()]

def execute(sql, params=()):
    with mysql.connector.connect(**CONFIG) as con, con.cursor() as cur:
        cur.execute(sql, params); con.commit(); return cur.lastrowid

def buscar_um(sql, params, mensagem):
    linhas = query(sql, params)
    if not linhas: raise ErroNegocio(mensagem, 404)
    return linhas[0]

def bloquear_se_existir(sql, params, mensagem):
    if query(sql, params): raise ErroNegocio(mensagem, 409)

def testar_conexao():
    return query("SELECT DATABASE() AS banco, VERSION() AS versao")[0]
