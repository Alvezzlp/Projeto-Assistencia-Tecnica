import re
import unittest
from pathlib import Path
from unittest.mock import patch

import bcrypt
from cryptography.fernet import Fernet

import autenticacao
import rotas
from app import app

ROOT = Path(__file__).resolve().parents[1]

class BasicSystemTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config.update(TESTING=True, SECRET_KEY="test-secret")
        sql = (ROOT / "assistencia_db.sql").read_text(encoding="utf-8")
        cls.admin_hash = re.search(r"\('Administrador','admin','(\$2b\$[^']+)'\)", sql).group(1)
        cls.sql = sql

    def test_login_api_success_and_logout(self):
        with app.test_client() as client, patch.object(autenticacao, "query", return_value=[{"id": 1, "nome": "Administrador", "senha_hash": self.admin_hash}]):
            res = client.post("/api/login", json={"login": "admin", "senha": "admin123"})
            self.assertEqual(res.status_code, 200)
            self.assertEqual(client.get("/api/me").json["nome"], "Administrador")
            self.assertEqual(client.post("/api/logout").status_code, 200)
            self.assertEqual(client.get("/api/me").status_code, 401)

    def test_login_rejects_wrong_password(self):
        with app.test_client() as client, patch.object(autenticacao, "query", return_value=[{"id": 1, "nome": "Administrador", "senha_hash": self.admin_hash}]):
            res = client.post("/api/login", json={"login": "admin", "senha": "incorreta"})
            self.assertEqual(res.status_code, 401)
            self.assertEqual(res.json["erro"], "Usuário ou senha inválidos.")

    def test_pages_are_protected(self):
        with app.test_client() as client:
            self.assertEqual(client.get("/clientes").status_code, 302)

    def test_cpf_fernet_round_trip(self):
        token = Fernet(b"ZDJPXW1P2xasuIaO73ZD_wwn4I6XXOA4UYnJCLrc060=").encrypt(b"12345678901").decode()
        self.assertNotEqual(token, "12345678901")
        self.assertEqual(Fernet(b"ZDJPXW1P2xasuIaO73ZD_wwn4I6XXOA4UYnJCLrc060=").decrypt(token.encode()), b"12345678901")

    def test_sql_has_three_records_per_table(self):
        for table in ("usuarios", "clientes", "aparelhos", "servicos", "agendamentos"):
            match = re.search(r"INSERT INTO " + table + r"\b.*?VALUES\s*(.*?);", self.sql, re.S | re.I)
            self.assertIsNotNone(match, table)
            self.assertGreaterEqual(len(re.findall(r"\([^()]*\)", match.group(1))), 3, table)

if __name__ == "__main__":
    unittest.main()
