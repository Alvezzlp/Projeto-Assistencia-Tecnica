# Roteiro de instalação e testes — Assistência Técnica de Celulares

## Requisitos
Python 3.10 ou superior e MySQL 8 ou superior em execução.

## 1. Ambiente e dependências
Abra o terminal na pasta `sistema` (onde estão `app.py` e `requirements.txt`):

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Configurar e criar o banco
O script cria o banco `assistencia_db` e insere pelo menos três registros em cada tabela. **Atenção:** ele contém `DROP DATABASE IF EXISTS assistencia_db`; importar novamente apaga e recria esse banco. Antes de executar, confirme que o usuário MySQL informado tem permissão para criar banco:

```bash
mysql -u root -p < assistencia_db.sql
```

Configure as variáveis de ambiente conforme sua instalação. Linux/macOS:

```bash
export DB_HOST=localhost DB_PORT=3306 DB_USER=root DB_PASSWORD='sua-senha'
export DB_NAME=assistencia_db SECRET_KEY='chave-secreta-longa'
# A chave de demonstração para CPF está documentada em .env.example; substitua-a
# por chave Fernet exclusiva antes de usar dados reais.
export CPF_ENCRYPTION_KEY='ZDJPXW1P2xasuIaO73ZD_wwn4I6XXOA4UYnJCLrc060='
```

No PowerShell, use `$env:DB_HOST="localhost"`, `$env:DB_USER="root"`, `$env:DB_PASSWORD="sua-senha"`, `$env:DB_NAME="assistencia_db"`, `$env:SECRET_KEY="chave-secreta-longa"` e `$env:CPF_ENCRYPTION_KEY="ZDJPXW1P2xasuIaO73ZD_wwn4I6XXOA4UYnJCLrc060="`.

## 3. Testar conexão e iniciar

```bash
python testar_conexao.py
python app.py
```

Acesse `http://localhost:5000`. A conexão só pode ser validada após iniciar o seu serviço MySQL.

## 4. Acesso de demonstração
Use `admin` / `admin123`, `carlos` / `carlos123` ou `ana` / `ana12345`. O login inválido apresenta mensagem genérica. A sessão expira em 30 minutos. A tela principal exibe o nome do usuário, menu de módulos e botão **Sair**.

## 5. Testes de funcionalidades
- Clientes: criar, pesquisar por nome/telefone/e-mail ou CPF completo, editar e excluir (exclusão bloqueada quando o cliente possui aparelho). O CPF é cifrado com Fernet; a tela nunca o exibe.
- Aparelhos: criar e editar aparelho selecionando um cliente existente; IMEI deve ter 15 dígitos e ser único.
- Agendamentos: criar, listar ordenado por data/hora, consultar dados de cliente/aparelho e reagendar.
- Teste da conexão: `GET /api/teste-conexao` exige autenticação.
- Logout: clique em **Sair** e confirme que `/principal` redireciona ao login.

## Observação de segurança
A chave padrão é apenas para demonstração/seed escolar. Em uso real gere uma chave Fernet própria, guarde-a em variável de ambiente ou gestor de segredos e mantenha cópia segura. Perder a chave impede decifrar os CPFs. O exemplo não substitui avaliação de segurança nem adequação integral à LGPD.
