"""Regras de clientes; CPF cifrado com Fernet e nunca devolvido à interface."""
import os, re
from cryptography.fernet import Fernet, InvalidToken
from db import ErroNegocio, bloquear_se_existir, buscar_um, execute, query

# Chave de demonstração para o material didático. Defina CPF_ENCRYPTION_KEY via ambiente
# em qualquer uso real e mantenha-a fora do código e do repositório.
CHAVE_DEMO = "ZDJPXW1P2xasuIaO73ZD_wwn4I6XXOA4UYnJCLrc060="
def _fernet():
    try: return Fernet(os.getenv("CPF_ENCRYPTION_KEY", CHAVE_DEMO).encode())
    except Exception as exc: raise RuntimeError("CPF_ENCRYPTION_KEY inválida; use uma chave Fernet válida.") from exc
COLUNAS = "id, nome, telefone, email, endereco, criado_em"
def so_digitos(texto): return re.sub(r"\D", "", texto or "")
def cpf_valido(cpf): return len(cpf) == 11
def _cifrar(cpf): return _fernet().encrypt(cpf.encode()).decode()
def _decifrar(token):
    try: return _fernet().decrypt(token.encode()).decode()
    except (InvalidToken, ValueError): return None
def _dono_do_cpf(cpf):
    if not cpf: return None
    for r in query("SELECT id, cpf_cifrado FROM clientes"):
        if _decifrar(r["cpf_cifrado"]) == cpf: return r["id"]
def _validar(d, id_=None):
    nome, email, cpf = (d.get("nome") or "").strip(), (d.get("email") or "").strip(), so_digitos(d.get("cpf"))
    if len(nome) < 3: raise ErroNegocio("Informe o nome completo.")
    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): raise ErroNegocio("E-mail inválido.")
    if (id_ is None or cpf) and not cpf_valido(cpf): raise ErroNegocio("CPF deve conter 11 dígitos.")
    if cpf and _dono_do_cpf(cpf) not in (None, id_): raise ErroNegocio("Já existe cliente com este CPF.", 409)
    return nome, cpf, email or None
def listar(termo=""):
    termo = (termo or "").strip()
    achados = query(f"SELECT {COLUNAS} FROM clientes WHERE nome LIKE %s OR email LIKE %s OR telefone LIKE %s ORDER BY nome", (f"%{termo}%",)*3)
    cpf = so_digitos(termo)
    dono = _dono_do_cpf(cpf) if cpf_valido(cpf) else None
    if dono and all(a["id"] != dono for a in achados): achados.append(obter(dono))
    return achados
def obter(id_): return buscar_um(f"SELECT {COLUNAS} FROM clientes WHERE id = %s", (id_,), "Cliente não encontrado.")
def cadastrar(d):
    nome, cpf, email = _validar(d)
    return obter(execute("INSERT INTO clientes (nome, cpf_cifrado, telefone, email, endereco) VALUES (%s,%s,%s,%s,%s)", (nome, _cifrar(cpf), d.get("telefone"), email, d.get("endereco"))))
def editar(id_, d):
    obter(id_); nome, cpf, email = _validar(d, id_)
    cifrado = _cifrar(cpf) if cpf else None
    execute("UPDATE clientes SET nome=%s, cpf_cifrado=COALESCE(%s, cpf_cifrado), telefone=%s, email=%s, endereco=%s WHERE id=%s", (nome, cifrado, d.get("telefone"), email, d.get("endereco"), id_))
    return obter(id_)
def excluir(id_):
    obter(id_)
    bloquear_se_existir("SELECT id FROM aparelhos WHERE cliente_id = %s", (id_,), "Cliente possui aparelhos cadastrados. Exclua-os antes.")
    execute("DELETE FROM clientes WHERE id = %s", (id_,))
